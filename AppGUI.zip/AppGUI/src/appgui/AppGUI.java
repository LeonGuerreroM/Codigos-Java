
package appgui;

/**
 *
 * @author leonmg
 */
public class AppGUI {

    public static void main(String[] args) {
        Ventana V1=new Ventana();
        V1.Init();
        Ventana2 V2=new Ventana2();
        V2.Init();
        Ventana3 V3=new Ventana3();
        V3.Init();
    }
    
}
