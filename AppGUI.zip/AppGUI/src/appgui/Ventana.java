
package appgui;

import java.awt.FlowLayout;
import javax.swing.*;

public class Ventana extends JFrame {
    JButton Letras[]; //arreglo de botones
    FlowLayout Flujo; //loyout de poner todo seguido de lado
    
    void Init(){
        String L[]={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
        Letras = new JButton[27];
        int i;
        
        Flujo = new FlowLayout();
        setLayout(Flujo); //poner el layout declarado
        
        for(i=0;i<27;i++){
            Letras[i]=new JButton(L[i]); //pone un String inicializado en el arreglo letras
            add(Letras[i]); //aplica el layout
        }
        
        setSize(400,240); //pone el tamaño
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //para cerrarlo
        setVisible(true); //Pa´que se vea
    }
}
