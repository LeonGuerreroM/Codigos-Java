/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appgui;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author Sala5
 */
public class Ventana2 extends JFrame /*Jframe es un contenedor en el que se adicionana elementos graficos y otros contendores*/ {
    JButton Letras[];
    GridLayout Rejilla;
    
    void Init(){
        String L[]={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
        Letras = new JButton[27];
        int i;
        
        Rejilla = new GridLayout(9,3);
        setLayout(Rejilla); //aplica el layout
        
        for(i=0;i<27;i++){
            Letras[i]=new JButton(L[i]); //pone un String inicializado en el arreglo letras
            add(Letras[i]); //agrega al layout
        }
        
        setSize(400,240); //pone el tamaño
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //para cerrarlo
        setVisible(true); //Pa´que se vea
}
}
