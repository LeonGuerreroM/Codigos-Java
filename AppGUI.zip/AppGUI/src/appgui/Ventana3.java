
package appgui;

import java.awt.*;
import javax.swing.*;

public class Ventana3 extends JFrame{
    JButton Letras[];
    GridLayout Rejilla;
    FlowLayout flujo1;
    FlowLayout flujo2;
    JLabel Palabra;
    JPanel Ahorcado;
    JPanel Botones;
    
    void Init(){
        String L[]={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","Ñ","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
        Rejilla = new GridLayout(2,1); //filas y columnas en los parentesis
        setLayout(Rejilla); //todo contenedor debe tener este metodo
        
        Ahorcado = new JPanel();
        Botones = new JPanel();
        
        flujo1=new FlowLayout();
        flujo2=new FlowLayout();
        
        Ahorcado.setLayout(flujo1);
        Botones.setLayout(flujo2);
        
        Palabra = new JLabel("*************");
        Ahorcado.add(Palabra);
        
        int i;
        Letras = new JButton[27];
        for(i=0;i<27;i++){
            Letras[i]=new JButton(L[i]);
            Botones.add(Letras[i]);
        }
       
        add(Ahorcado);
        add(Botones);
        
        setSize(400,240); //pone el tamaño
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //para cerrarlo
        setVisible(true); //Pa´que se vea
        
    }
}
