/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graficosapp;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/**
 *
 * @author Sala5
 */
public class Lienzo extends JPanel {
    
   ImageIcon Imagen; 
   boolean dibujar=true;
   int x=0, y=0;
   public void Init(){
       Imagen=new ImageIcon(this.getClass().getResource("FondoMenu.png"));
   }
   
   
   @Override
   public void paint(Graphics G){
       /*int i, j;
       if(dibujar==true){
       for(i=0;i<200;i=i+50)//hace un ciclo para que se repita la imagen
           for(j=0;j<200;j=j+50)*/
            G.drawImage(Imagen.getImage(), x, y, 50, 50, null);
            //dibujar=false;
       //}
   //}
   }
    
   public void SetXY(int x, int y){
       this.x=x;
       this.y=y;
   }
    
} 
    

